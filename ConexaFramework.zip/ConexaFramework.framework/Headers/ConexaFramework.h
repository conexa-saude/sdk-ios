//
//  ConexaFramework.h
//  ConexaFramework
//
//  Created by Conexa on 05/07/19.
//  Copyright © 2019 Conexa. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ConexaFramework.
FOUNDATION_EXPORT double ConexaFrameworkVersionNumber;

//! Project version string for ConexaFramework.
FOUNDATION_EXPORT const unsigned char ConexaFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ConexaFramework/PublicHeader.h>

//#import <MobileRTC/MobileRTC.h>
